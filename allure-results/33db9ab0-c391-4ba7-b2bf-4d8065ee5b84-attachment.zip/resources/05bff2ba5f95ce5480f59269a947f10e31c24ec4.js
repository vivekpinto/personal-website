window.addEventListener("DOMContentLoaded", () => {
  const RUNNING_CLASS = "is-running";
  const STOPPED_CLASS = "is-stopped";
  const TIMEOUT = 5000;
  const circles = document.querySelectorAll('.pause-animation-js');
  if(!circles.length) {
    return ;
  }
  const pauseTimers = new WeakMap();

  const runThenPause = (el) => {
    el.classList.add(RUNNING_CLASS);

    const existingTimerId = pauseTimers.get(el);
    if (existingTimerId) clearTimeout(existingTimerId);
    const timerId = setTimeout(() => {
      el.classList.add(STOPPED_CLASS);
      pauseTimers.delete(el);
    }, TIMEOUT);

    pauseTimers.set(el, timerId);
  };

  function getPxToSvg(viewBox, rect, svgEl) {
    const scaleX = viewBox.width / rect.width;
    const scaleY = viewBox.height / rect.height;
    const pa = svgEl.getAttribute('preserveAspectRatio') ?? 'xMidYMid meet';
    if (pa.includes('none')) {
      return Math.sqrt(scaleX * scaleY);
    }
    return Math.max(scaleX, scaleY);
  }

  function normalizeDotSize(svgEl, cachedCircles, targetPxRadius = 8) {
    if (!svgEl) return;
    const viewBox = svgEl.viewBox?.baseVal;
    if (!viewBox || !viewBox.width || !viewBox.height) return;
    const rect = svgEl.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    const pxToSvg = getPxToSvg(viewBox, rect, svgEl);

    cachedCircles.forEach(c => {
      const rSvgUnits = c.r?.baseVal?.value ?? 0;
      if (!rSvgUnits) return;

      const strokeSvgUnits = parseFloat(getComputedStyle(c).strokeWidth) || 0;
      const visualScreenR = (rSvgUnits + strokeSvgUnits / 2) / pxToSvg;
      const scaleFactor = targetPxRadius / visualScreenR;

      c.style.transformBox = 'fill-box';
      c.style.transformOrigin = 'center';
      c.style.transform = `scale(${scaleFactor})`;
    });
  }

  const svgCache = new Map();
  circles.forEach((circle) => {
    const svgEl = circle.querySelector('svg');
    if (!svgEl) return;
    const circleEls = Array.from(svgEl.querySelectorAll('circle'));
    svgCache.set(svgEl, circleEls);
  });

  function normalizeAllDots() {
    svgCache.forEach((circleEls, svgEl) => {
      normalizeDotSize(svgEl, circleEls);
    });
  }

  normalizeAllDots();
  let rafId = null;

  const resizeObserver = new ResizeObserver(() => {
    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(() => {
      normalizeAllDots();
      rafId = null;
    });
  });

  // Observe each SVG on resize
  svgCache.forEach((_, svgEl) => resizeObserver.observe(svgEl));

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      const el = entry.target;
      if (entry.isIntersecting) {
        runThenPause(el);
        obs.unobserve(el);
      }
    });
    },
    {
      root: null,
      threshold: 0,
      rootMargin: "0px 0px 0px 0px",
    }
  );

  circles.forEach((el) => {
    observer.observe(el);
  });
});

