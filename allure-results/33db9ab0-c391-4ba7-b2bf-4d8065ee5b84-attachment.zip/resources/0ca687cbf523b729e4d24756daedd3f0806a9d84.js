document.addEventListener("DOMContentLoaded", () => {
    document.addEventListener('focusin', (e) => {
        const navbar = document.querySelector('.zeus-navbar');
        const skipMainContent = document.querySelector('.skip-link');
        if (!navbar) return;
        if (navbar.contains(e.target) || skipMainContent.contains(e.target)) return;
        if (e.target.tagName === 'VIDEO') return;

        const navbarBottom = navbar.getBoundingClientRect().bottom;
        const elemRect = e.target.getBoundingClientRect();
    
        if (elemRect.top < navbarBottom) {
            const scrollAmount = navbarBottom - elemRect.top + 16; // 16px buffer	
            window.scrollBy({ top: -scrollAmount, behavior: 'smooth' });
        }
    });
})
