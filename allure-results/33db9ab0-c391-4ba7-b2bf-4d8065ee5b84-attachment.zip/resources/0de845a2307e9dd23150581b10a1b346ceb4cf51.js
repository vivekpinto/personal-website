document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.zeus-header');
  const items = document.querySelectorAll('.zeus-nav-item.has-dropdown');
  const allItems = document.querySelectorAll('.zeus-nav-item');
  const navLink = document.querySelectorAll('.zeus-nav-item.is-link')[0];    
  
  let lastScroll = 0;
  let ticking = false;
  const scrollDelta = 8;
  const getFocusable = (root) =>
    Array.from(root.querySelectorAll(`
      a[href],
      button:not([disabled]),
      [tabindex]:not([tabindex="-1"])
    `));

  const toggleHeaderVisibility = () => {
    if (!header) return;
    const current = window.scrollY;
    const scrollingDown = current > lastScroll + scrollDelta;
    const scrollingUp = current < lastScroll - scrollDelta;

    if (current <= 0 || scrollingUp) {
      header.classList.remove('is-hidden');
    } else if (scrollingDown) {
      header.classList.add('is-hidden');
    }

    lastScroll = current;
    ticking = false;
  };

  window.addEventListener('scroll', () => {
    if (!ticking) {
      window.requestAnimationFrame(toggleHeaderVisibility);
      ticking = true;
    }
  }, { passive: true });

  const closeAll = () => {
    items.forEach(el => {
      el.classList.remove('is-open');
      el.classList.remove('is-locked');
      const trigger = el.querySelector('.zeus-nav-trigger');
      trigger?.setAttribute('aria-expanded', 'false');
    });
  };

  items.forEach((item,index) => {
    const trigger = item.querySelector('.zeus-nav-trigger');	

    // 1. HOVER ENTER
    item.addEventListener('mouseenter', () => {
      items.forEach(el => {
        if (el !== item) el.classList.remove('is-open');
      });
      
      item.classList.add('is-open');
      trigger?.setAttribute('aria-expanded', 'true');
    });

    // 2. HOVER LEAVE
    item.addEventListener('mouseleave', () => {
      if (!item.classList.contains('is-locked')) {
        item.classList.remove('is-open');
        trigger?.setAttribute('aria-expanded', 'false');
      }
    });

    // 3. CLICK
    item.addEventListener('click', (e) => {
      e.stopPropagation();
      if (e.target.closest('.zeus-dropdown-panel')) return;

      const isLocked = item.classList.contains('is-locked');
      items.forEach(el => {
        if (el !== item) {
            el.classList.remove('is-open');
            el.classList.remove('is-locked');
        }
      });

      if (isLocked) {
        item.classList.remove('is-locked');
        item.classList.remove('is-open');
        trigger?.setAttribute('aria-expanded', 'false');
      } else {
        // Lock and Open
        item.classList.add('is-locked');
        item.classList.add('is-open');
        trigger?.setAttribute('aria-expanded', 'true');
      }
    });

	item?.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openDropdown(item, index);		
      }
    });
  });

  // 4. OUTSIDE CLICK
  document.addEventListener('click', closeAll);

  // Mobile menu toggle + accordion logic mirrors desktop IA without altering desktop interactions.
  const menuToggle = document.querySelector('.zeus-menu-toggle');
  const mobileMenu = document.querySelector('.zeus-mobile-menu');
  const mobileBackdrop = document.querySelector('.zeus-mobile-menu__backdrop');
  const mobileAccordionTriggers = document.querySelectorAll('[data-mobile-accordion]');
  const mobileLinks = document.querySelectorAll('.zeus-mobile-menu__panel a');

  let activeDropdown = null;
  let activeIndex = null;

  const openDropdown = (item, index) => {
    closeAll();

    activeDropdown = item;
	activeIndex = index;
    item.classList.add('is-open');

    const trigger = item.querySelector('.zeus-nav-trigger');
    trigger?.setAttribute('aria-expanded', 'true');

	const subLinks = getFocusable(item);
	subLinks.forEach((subLink, index) => {
		subLink?.addEventListener('keydown', e => {
			if (e.key == 'Enter' || e.key == '') {
				subLinks[index].click();
			}
		})
	})	

    document.addEventListener('keydown', trapDropdownFocus);	
  };

  navLink.addEventListener('keydown', e => {
	if (e.key == 'Enter' || e.key == '') {
		navLink.click();
	}
  })

  const setMobileMenuState = (isOpen) => {
    if (!mobileMenu || !menuToggle) return;
    mobileMenu.classList.toggle('is-open', isOpen);
    mobileMenu.setAttribute('aria-hidden', String(!isOpen));
	if (isOpen) {
		mobileMenu.removeAttribute('inert');
	} else {
		mobileMenu.setAttribute('inert', '');
	}
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Close main menu' : 'Open main menu');
    document.body.classList.toggle('zeus-mobile-menu-open', isOpen);
  };

  const closeMobileMenu = () => setMobileMenuState(false);

  menuToggle?.addEventListener('click', (event) => {
    event.stopPropagation();
    const isOpen = mobileMenu?.classList.contains('is-open');
    setMobileMenuState(!isOpen);
  });

  mobileBackdrop?.addEventListener('click', closeMobileMenu);

  mobileAccordionTriggers.forEach(trigger => {
    trigger.addEventListener('click', () => {
      const expanded = trigger.getAttribute('aria-expanded') === 'true';
      const submenu = trigger.nextElementSibling;
      trigger.setAttribute('aria-expanded', String(!expanded));
      trigger.classList.toggle('is-open', !expanded);
      if (submenu) {
        submenu.toggleAttribute('hidden', expanded);
      }
    });
  });

  mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeMobileMenu();
    });
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeMobileMenu();
      closeAll();
    }
  });

  const trapDropdownFocus = (e) => {
    if (!activeDropdown) return;	

    const focusables = getFocusable(
      activeDropdown.querySelector('.zeus-dropdown-panel')
    );	

    if (!focusables.length) return;

    const first = focusables[0];
    const last = focusables[focusables.length - 1];	

    switch (e.key) {

      case 'Tab':
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        }
        if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
		  getFocusable(allItems[activeIndex + 1])[0].focus()
		  closeAll();
        }
        break;

      case 'ArrowDown':
        e.preventDefault();
        moveFocus(focusables, 1, activeIndex);
        break;

      case 'ArrowUp':
        e.preventDefault();
        moveFocus(focusables, -1, activeIndex);
        break;
    }
  };

  const moveFocus = (list, step, activeMenuIndex) => {
    const index = list.indexOf(document.activeElement);
    if (index === -1) return;

    let next = index + step;

    if (next < 0) next = list.length - 1;
    if (next >= list.length) {
		closeAll();
		getFocusable(allItems[activeMenuIndex + 1])[0].focus()
	}

    if (next < list.length) {
		list[next].focus();
	}
  };

  window.addEventListener('resize', () => {
    if (window.innerWidth >= 768) {
      closeMobileMenu();
    }
  });
});