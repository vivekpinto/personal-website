const initHomePage = () => {
  const section = document.querySelector('.section-3');
  const track = document.querySelector('.services-list');
  const zeusHeader = document.querySelector('.zeus-header');
  const serviceHeader = document.querySelector('.services-header');
  const serviceShell = document.querySelector('.services-shell')
  const listWrapper = document.querySelector('.services-list-wrapper');
  const productAccordions = Array.from(document.querySelectorAll('[data-product-accordion]'));
  const productCards = Array.from(document.querySelectorAll('[data-product-card]'));
  const homeAniamtionSection = document.querySelector('.camera-container');
  let isHeroPaused = false;

  // Animation related code
  const path = document.querySelector('#motion-path-p1');
  const dot = document.querySelector('#moving-dot-p1');
  const path1 = document.querySelector('#motion-path-p2');
  const dot1 = document.querySelector('#moving-dot-p2');
  const cards = document.querySelectorAll('.service-card');

  // typewriter
  const element = document.querySelector('.elearning-content-animation-section__highlight__content');
  const elementParent = document.querySelector('.elearning-content-animation-section__highlight');
  const highlightRotator = document.querySelector('[data-highlight-rotator]');
  const sentencesRaw = highlightRotator?.getAttribute('data-highlights') ?? '[]';
  let sentences = [];
  const desktopScreenViewport = 1024;

  if (serviceShell && section && window.innerWidth > desktopScreenViewport) {
    const viewportMiddle = (window.innerHeight - listWrapper.offsetHeight - serviceHeader.offsetHeight - zeusHeader.offsetHeight)  / 2;      
    serviceShell.style.top = `${viewportMiddle}px`;
    serviceShell.style.marginBottom = `${viewportMiddle}px`;
  }

  // link styled as buttons
  const talkToUsBtn = document.getElementById('talkToUs');
  const servicesCtaBtn = document.getElementById('servicesCta');
  const elearningCtaBtn = document.getElementById('elearningCta');
  const projectCtaAboutUsBtn = document.getElementById('projectCtaAboutUs')

  talkToUsBtn.addEventListener('click', () => handleLinkButtonsOnClick(talkToUsBtn));
  servicesCtaBtn.addEventListener('click', () => handleLinkButtonsOnClick(servicesCtaBtn));
  elearningCtaBtn.addEventListener('click', () => handleLinkButtonsOnClick(elearningCtaBtn));
  projectCtaAboutUsBtn.addEventListener('click', () => handleLinkButtonsOnClick(projectCtaAboutUsBtn));

  function handleLinkButtonsOnClick(el) {
    const location = el.dataset.location;
    if (location) {
      window.location.assign(location);
    }
  }

  try {
    sentences = JSON.parse(sentencesRaw);
  } catch (error) {
    console.warn('Failed to parse highlight sentences.', error);
  }

  const typingSpeed = 100;
  const deletingSpeed = 50;
  const pauseTime = 2000;
  const headerHeight = 56;

  let sentenceIndex = 0;
  let charIndex = 0;
  let isDeleting = false;

  if (cards.length === 0) {
    console.warn('no card found');
  }

  const numCards = cards.length;
  const numTransitions = numCards - 1;
  const dotMinDist = 8.5;
  const dot1MinDist = 8;
  const color0 = '#4800BA';
  const color1 = '#8C3A70';
  const color3 = '#0652B4';

  const canAnimatePath = path && path1 && dot && dot1;
  const pathLength = canAnimatePath ? path.getTotalLength() : 0;
  const pathLength2 = canAnimatePath ? path1.getTotalLength() : 0;

  const MOBILE_BREAKPOINT = 1025;
  const PADDING_OFFSET = 160;
  const PRODUCT_DESKTOP_BREAKPOINT = 768;
  const upperLimit1 = 155;
  const upperLimit2 = 142;

  let dimensions = {
    top: 0,
    height: 0,
    trackWidth: 0,
    maxTranslate: 0,
    windowHeight: 0,
    windowWidth: 0
  };

  function updateDimensions() {
    if (!section || !track) return;

    const rect = section.getBoundingClientRect();
    dimensions.top = window.scrollY + rect.top;
    dimensions.height = rect.height;
    dimensions.windowHeight = window.innerHeight;
    dimensions.windowWidth = window.innerWidth;
    dimensions.trackWidth = track.scrollWidth;
    dimensions.maxTranslate = dimensions.trackWidth - dimensions.windowWidth + PADDING_OFFSET;
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function getWidth() {
    if (!serviceShell || !listWrapper) return 0;
    const s = getComputedStyle(serviceShell).paddingLeft;
    const l = getComputedStyle(listWrapper).paddingLeft;
    return (parseFloat(s) || 0) + (parseFloat(l) || 0);
  }

  function getTranslateXToCenterCard(targetIndex) {
    const card = cards[targetIndex];
    if (!card) return 0;
    const cardLeft = card.offsetLeft;
    const cardWidth = card.offsetWidth;
    const cardCenter = cardLeft + cardWidth / 2;
    const viewportCenter = window.innerWidth / 2;
    const translateX = viewportCenter - cardCenter - getWidth();
    return clamp(translateX, -dimensions.maxTranslate, 0);
  }

  function scrollToVerticalForTranslateX(translateX) {
    const percentage = clamp(Math.abs(translateX) / dimensions.maxTranslate, 0, 1);
    const scrollableDistance = dimensions.height - dimensions.windowHeight;
    const targetY = dimensions.top + percentage * scrollableDistance;
    window.scrollTo({ top: targetY, behavior: 'instant' });
  }

  const productsLinks = Array.from(document.querySelectorAll('.service-link.tertiry-button-hover'));
  productsLinks.forEach((link, index) =>{
    link.addEventListener('keydown', (e)=>{
      if (e.key !== 'Tab') return;

      const targetIndex = e.shiftKey
        ? Math.max(index - 1, 0)
        : Math.min(index + 1, cards.length - 1);

      const translateX = getTranslateXToCenterCard(targetIndex);
      track.style.transform = `translateX(${translateX}px)`;
      scrollToVerticalForTranslateX(translateX);
    })
  })

  let isServicesInView = false;
  let scrollScheduled = false;

  function animateOnScroll() {
    if (!track) return;
    if (window.innerWidth < MOBILE_BREAKPOINT) {
      track.style.transform = 'translateX(0)';
      return;
    }

    if (!canAnimatePath || numTransitions <= 0) return;

    const scrollTop = window.scrollY;
    const scrollableDistance = dimensions.height - dimensions.windowHeight;
    let percentage = (scrollTop - dimensions.top) / scrollableDistance;
    percentage = Math.max(0, Math.min(1, percentage));

    const translateX = -(percentage * dimensions.maxTranslate);
    track.style.transform = `translateX(${translateX}px)`;

    const transitionSize = 1 / numTransitions;
    let p1 = (percentage - 0) / transitionSize;
    p1 = Math.min(Math.max(p1, 0), 1);
    let p2 = (percentage - transitionSize) / transitionSize;
    p2 = Math.min(Math.max(p2, 0), 1);

    const point1 = path.getPointAtLength((1 - p1) * pathLength);
    const point2 = path1.getPointAtLength(p2 * pathLength2);

    if (p1 >= 0.9) {
      dot.setAttribute('fill', color1);
    } else {
      dot.setAttribute('fill', color0);
    }

    if (p2 >= 0.9) {
      dot1.setAttribute('fill', color3);
    } else {
      dot1.setAttribute('fill', color1);
    }

    const clampedXDot = Math.min(Math.max(point1.x, dotMinDist), upperLimit1);
    const clampedXDot1 = Math.min(Math.max(point2.x, dot1MinDist), upperLimit2);
    dot.setAttribute('cx', clampedXDot);
    dot.setAttribute('cy', point1.y);
    dot1.setAttribute('cx', clampedXDot1);
    dot1.setAttribute('cy', point2.y);
  }

  const servicesObserver = new IntersectionObserver(
    ([entry]) => {
      isServicesInView = Boolean(entry && entry.isIntersecting);
      if (isServicesInView) {
        updateDimensions();
        if (!scrollScheduled) {
          scrollScheduled = true;
          window.requestAnimationFrame(() => {
            scrollScheduled = false;
            animateOnScroll();
          });
        }
      }
    },
    { root: null, rootMargin: '200px 0px', threshold: 0.01 }
  );

  if (section) {
    servicesObserver.observe(section);
  }

  function handleProductToggle(event) {
    const accordion = event.target?.closest?.('[data-product-accordion]');
    if (!accordion || !(accordion instanceof HTMLDetailsElement)) return;

    if (accordion.dataset.forcedOpen === 'true' && !accordion.open) {
      accordion.setAttribute('open', '');
    }

    if (accordion.open) {
      productAccordions.forEach((otherAccordion) => {
        if (otherAccordion !== accordion) {
          otherAccordion.removeAttribute("open");
        }
      });
    }
  }

  productAccordions.forEach((accordion) => {
    accordion.addEventListener('toggle', handleProductToggle);
  });

  function setMaxWidth() {
    if (!element || !elementParent || !sentences.length) return;

    const testSpan = document.createElement('span');
    testSpan.style.visibility = 'hidden';
    testSpan.style.position = 'absolute';
    testSpan.style.whiteSpace = 'nowrap';
    testSpan.style.font = getComputedStyle(elementParent).font;
    document.body.appendChild(testSpan);

    let maxWidth = 0;
    let maxHeight = 0;
    sentences.forEach((text) => {
      testSpan.textContent = text;
      const width = testSpan.getBoundingClientRect().width;
      const height = testSpan.getBoundingClientRect().height;
      if (width > maxWidth) maxWidth = width;
      if (height > maxHeight) maxHeight = height;
    });

    document.body.removeChild(testSpan);
    element.style.width = `${maxWidth + 25}px`;
    element.style.height = `${maxHeight + 10}px`;
  }

  function type() {
    if (isPaused) return;
    if (!element || !sentences.length) return;
    const currentSentence = sentences[sentenceIndex];

    if (isDeleting) {
      element.textContent = currentSentence.substring(0, charIndex - 1);
      charIndex--;
    } else {
      element.textContent = currentSentence.substring(0, charIndex + 1);
      charIndex++;
    }

    let nextSpeed = isDeleting ? deletingSpeed : typingSpeed;

    if (!isDeleting && charIndex === currentSentence.length) {
      isDeleting = true;
      nextSpeed = pauseTime;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      sentenceIndex = (sentenceIndex + 1) % sentences.length;
      nextSpeed = 500;
    }

    setTimeout(type, nextSpeed);
  }

  function updateServiceShellGap() {
    const wrapperHeight = track.offsetHeight;
    const serviceShellStyles = window.getComputedStyle(serviceShell);  
    const availabelHeight = window.innerHeight - serviceHeader.offsetHeight - headerHeight - Number.parseInt(serviceShellStyles["paddingTop"]) - Number.parseInt(serviceShellStyles["gap"]);
    if (availabelHeight <= wrapperHeight) {
      serviceShell.style.gap = "24px";
    }
  }

  updateServiceShellGap()

  // Control functions
  function pauseTyping() {
    isPaused = true;
  }

  function resumeTyping() {
    if (isPaused) {
      isPaused = false;
      type(); // resume from current position
    }
  }


  window.addEventListener(
    'resize',
    () => {
      window.requestAnimationFrame(() => {
        updateDimensions();
        animateOnScroll();
        setMaxWidth();
        updateServiceShellGap();
        setupHomeAnimationObserver();
        syncHeroAnimationState();
      });
    },
    { passive: true }
  );

  window.addEventListener(
    'scroll',
    () => {
      if (!isServicesInView || scrollScheduled) return;
      scrollScheduled = true;
      window.requestAnimationFrame(() => {
        scrollScheduled = false;
        animateOnScroll();
      });
    },
    { passive: true }
  );

  updateDimensions();
  animateOnScroll();

  function animateCounter(element) {
    const numberDisplay = element.querySelector('.numbers-stat__number');
    const target = parseInt(element.dataset.target, 10);
    if (!numberDisplay || Number.isNaN(target)) return;
    const digits = target.toString().length;
    const start = 0;
    const duration = 2000;
    let startTime = null;

    function update(currentTime) {
      if (startTime == null) {
        startTime = currentTime;
      }
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const value = start + (target - start) * progress;
      const current = Math.floor(value);
      numberDisplay.textContent = current.toString().padStart(digits, '0');

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        numberDisplay.textContent = target.toString().padStart(digits, '0');
      }
    }

    requestAnimationFrame(update);
  }

  const viewport = document.getElementById('viewport');
  const world = document.getElementById('world');
  const svg = document.getElementById('scene');
  const overlay = document.getElementById('overlay');
  const wavePath = document.getElementById('wavePath');
  const ball = document.getElementById('ball');
  const markers = Array.from(document.querySelectorAll('.marker'));
  const stampGroups = Array.from(document.querySelectorAll('.stamp-group'));
  const MARKER_FADEOUT_TIMESTAMP = 20500;
  let animationStarted = false;
  let homeAnimationObserverCreated = false;
  let startAnimation = () => {};

  setMaxWidth();
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry && entry.isIntersecting) {
        animateCounter(entry.target);
        counterObserver.unobserve(entry.target);
      }
    });
  });

  const observerOptions = { root: null, rootMargin: '0px', threshold: 0.3 };

  const typeObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry && entry.isIntersecting) {
        type();
        typeObserver.unobserve(entry.target);
      }
    });
  }, observerOptions);

  if (highlightRotator) typeObserver.observe(highlightRotator);

  const setupHomeAnimationObserver = () => {
    if(homeAniamtionSection && window.innerWidth >= 768 && !homeAnimationObserverCreated) {
      homeAnimationObserverCreated = true;
      const homeAnimationObserver = new IntersectionObserver(
        ([entry], obs) => {
          if (entry?.isIntersecting) {
            const section = entry.target;
            startAnimation();
            obs.unobserve(section);
          }
        },
        { root: null, rootMargin: '300px 0px', threshold: 0.01 }
      );
  
      homeAnimationObserver.observe(homeAniamtionSection);
    }
  }

  document
    .querySelectorAll('.numbers-stat[data-target]')
    .forEach((el) => counterObserver.observe(el));

  const totalAnimationTime = 21000;
  const startTime = performance.now();
  let paused = false;
  let pauseAnimationTime = 0;
  let resumeAnimationTime = 0;
  const VIEWBOX_W = 3536;
  const VIEWBOX_H = 655;
  const totalLength = wavePath.getTotalLength();

  const SPEED_PX_PER_MS = 0.17;
  const PAUSE_DURATION = 50;
  const VISUAL_OFFSET_X = 100;
  const stages = [
    { top: 100, left: 0, time: 0 },
    { top: -300, left: 0, time: 6000 },
    { top: -300, left: -850, time: 7000 },
    { top: 0, left: -1490, time: 14000 }
  ];

  let lastTime = performance.now();
  let currentDist = 0;
  let resumeTime = 0;
  let camX = 0;
  let camY = 0;
  let targetCamX = 0;
  let targetCamY = 0;
  let currentStage = 0;

  function svgToScreen(svgX, svgY, ctm, overlayRect) {
    const pt = svg.createSVGPoint();
    pt.x = svgX;
    pt.y = svgY;
    const screenPt = pt.matrixTransform(ctm);
    return {
      x: screenPt.x - overlayRect.left,
      y: screenPt.y - overlayRect.top
    };
  }

  if (!viewport || !world || !svg || !wavePath || !ball) {
    console.warn('Elements missing.');
  } else {
    const pathPoints = [];
    for (let l = 0; l <= totalLength; l += 2) {
      const p = wavePath.getPointAtLength(l);
      pathPoints.push(p);
    }

    function getPointForX(targetX) {
      return pathPoints.reduce((prev, curr) =>
        Math.abs(curr.x - targetX) < Math.abs(prev.x - targetX) ? curr : prev
      );
    }

    stampGroups.forEach((group) => {
      const targetX = parseFloat(group.dataset.x);
      const p = getPointForX(targetX);
      group.dataset.finalX = p.x;
      group.querySelectorAll('circle').forEach((c) => {
        c.setAttribute('cx', p.x);
        c.setAttribute('cy', p.y);
      });
    });

    markers.forEach((marker) => {
      const targetX = parseFloat(marker.dataset.x);
      const p = getPointForX(targetX);
      marker.dataset.y = p.y;
    });

    wavePath.style.strokeDasharray = `${totalLength} ${totalLength}`;
    wavePath.style.strokeDashoffset = totalLength;

    const stages = [
      { endX: 1050, focusX: 500, focusY: 200 },
      { endX: 2100, focusX: 1600, focusY: 500 },
      { endX: 9999, focusX: 2800, focusY: 300 }
    ];

    function lerp(start, end, factor) {
      return start + (end - start) * factor;
    }

    function clamp(v, min, max) {
      return Math.max(min, Math.min(max, v));
    }

    function positionOverlayElements() {
      if (!animationStarted) startAnimation();
      const ctm = svg.getScreenCTM();
      if (!ctm) return;
      const overlayRect = overlay.getBoundingClientRect();

      markers.forEach((el) => {
        const x = parseFloat(el.dataset.x);
        const y = parseFloat(el.dataset.y);
        const pt = svg.createSVGPoint();
        pt.x = x;
        pt.y = y;
        const screenPt = pt.matrixTransform(ctm);
        el.style.left = `${screenPt.x - overlayRect.left}px`;
        el.style.top = `${screenPt.y - overlayRect.top}px`;
      });
    }

    function tickOld(now) {
      const dt = now - lastTime;
      lastTime = now;

      if (now > resumeTime) {
        currentDist += SPEED_PX_PER_MS * dt;
      }

      if (currentDist >= totalLength) {
        currentDist = 0;
        currentStage = 0;
        markers.forEach((m) => m.classList.remove('revealed'));
        stampGroups.forEach((g) => {
          g.classList.remove('active');
          g.classList.remove('paused-at');
        });
        resumeTime = 0;
      }

      const p = wavePath.getPointAtLength(currentDist);

      const ctm = svg.getScreenCTM();
      if (ctm) {
        const overlayRect = overlay.getBoundingClientRect();
        const screenPos = svgToScreen(p.x, p.y, ctm, overlayRect);
        ball.style.left = `${screenPos.x}px`;
        ball.style.top = `${screenPos.y}px`;
      }

      wavePath.style.strokeDashoffset = totalLength - currentDist;

      stampGroups.forEach((group) => {
        const stampX = parseFloat(group.dataset.finalX);
        if (p.x >= stampX && !group.classList.contains('active')) {
          group.classList.add('active');
          if (!group.classList.contains('paused-at')) {
            resumeTime = now + PAUSE_DURATION;
            group.classList.add('paused-at');
          }
        }
      });

      if (currentStage < stages.length - 1) {
        if (p.x > stages[currentStage].endX) currentStage++;
      }

      const vp = viewport.getBoundingClientRect();
      const wr = world.getBoundingClientRect();
      const scaleX = wr.width / VIEWBOX_W;
      const scaleY = wr.height / VIEWBOX_H;

      const maxScrollX = -(wr.width - vp.width);
      const maxScrollY = -(wr.height - vp.height);

      const focusPx = stages[currentStage].focusX * scaleX;
      const desiredX = vp.width / 2 - focusPx + VISUAL_OFFSET_X;
      targetCamX = clamp(desiredX, Math.min(0, maxScrollX), 0);

      const focusPy = stages[currentStage].focusY * scaleY;
      const desiredY = vp.height / 2 - focusPy;
      targetCamY = clamp(desiredY, Math.min(0, maxScrollY), 0);

      camX = lerp(camX, targetCamX, 0.04);
      camY = lerp(camY, targetCamY, 0.04);

      if (Math.abs(camX - targetCamX) < 0.2) camX = targetCamX;
      if (Math.abs(camY - targetCamY) < 0.2) camY = targetCamY;

      world.style.transform = `translate(${camX}px, ${camY}px)`;

      markers.forEach((el) => {
        const mx = parseFloat(el.dataset.x);
        if (!el.classList.contains('revealed') && p.x >= mx) {
          el.classList.add('revealed');
        }
      });

      positionOverlayElements();
      requestAnimationFrame(tickOld);
    }

    startAnimation = () => {
      animationStarted = true;
      world.style.opacity = 1;
      paused = false;
      pauseAnimationTime = 0;
      resumeAnimationTime = 0;

      markers.forEach((el) => {
        el.style.transition = 'top 0.5s linear, left 0.5s linear';
      });
      requestAnimationFrame(tick);
    }
    setupHomeAnimationObserver();
  }

  const tick = () => {
    const currentTime = performance.now();
    let animationPosTime;
    if (paused) {
      animationPosTime = pauseAnimationTime; // freeze at pause time
    } else {
      animationPosTime = (currentTime - startTime - resumeAnimationTime) % totalAnimationTime;
    }
    let currentStage = -1;

    for (let i = 0; i < stages.length; i++) {
      if (stages[i].time > animationPosTime) break;
      currentStage++;
    }

    const stage = stages[currentStage];
    const worldRect = world.getBoundingClientRect();
    const scale = worldRect.width / VIEWBOX_W;

    world.style.transform = `translate(${stage.left * scale}px, ${stage.top * scale}px) scale(1.72, 1.72)`;
    world.style.transformOrigin = '0 0';
    if (currentStage != 0) {
      world.style.transition = 'transform 0.5s linear';
    }

    currentDist = (animationPosTime * totalLength) / totalAnimationTime;

    if (currentDist >= totalLength) {
      currentDist = 0;
      currentStage = 0;
      markers.forEach((m) => m.classList.remove('revealed'));
      stampGroups.forEach((g) => {
        g.classList.remove('active');
        g.classList.remove('paused-at');
      });
      resumeTime = 0;
    }

    const p = wavePath.getPointAtLength(currentDist);
    const ctm = svg.getScreenCTM();
    if (ctm) {
      const overlayRect = overlay.getBoundingClientRect();
      const screenPos = svgToScreen(p.x, p.y, ctm, overlayRect);
      ball.style.left = `${screenPos.x}px`;
      ball.style.top = `${screenPos.y}px`;
    }

    wavePath.style.strokeDashoffset = totalLength - currentDist;

    stampGroups.forEach((group) => {
      const stampX = parseFloat(group.dataset.finalX);
      if (p.x >= stampX) {
        if (!group.classList.contains('active')) group.classList.add('active');
      } else {
        group.classList.remove('active');
        group.classList.remove('paused-at');
      }
    });

    const markerPositionAdjustFactor = [
      { x: -50, y: -25 },
      { x: -6.5, y: -50 },
      { x: -9, y: -50 },
      { x: -9, y: -50 },
      { x: -50, y: -25 },
      { x: -50, y: -80 },
      { x: -93, y: -50 },
      { x: -50, y: -23 },
      { x: -50, y: -80 }
    ];

    markers.forEach((el, index) => {
      const elPosAdjust = markerPositionAdjustFactor[index];
      const pt = svg.createSVGPoint();
      pt.x = parseFloat(el.dataset.x);
      pt.y = parseFloat(el.dataset.y);

      const elPosAdjustX = (elPosAdjust.x / 100) * el.offsetWidth;
      const elPosAdjustY = (elPosAdjust.y / 100) * el.offsetHeight;

      el.style.transition = 'transform 0.5s linear, opacity 0.5s linear';
      el.style.transform = `translate(${pt.x * scale + stage.left * scale + elPosAdjustX}px, ${pt.y * scale + stage.top * scale + elPosAdjustY}px)`;
    });

    let markerCounter = 0;
    markers.forEach((el) => {
      const mx = parseFloat(el.dataset.x);
      if (p.x >= mx) markerCounter++;
    });

    markers.forEach((el, index) => {
      const mx = parseFloat(el.dataset.x);
      const setIndex = Math.ceil(markerCounter / 3);
      // animationPosTime < MARKER_FADEOUT_TIMESTAMP => this condition fades out the last 3 markers before they translate diagonally
      if (p.x >= mx && Math.ceil((index + 1) / 3) === setIndex && (animationPosTime < MARKER_FADEOUT_TIMESTAMP)) {
        if (!el.classList.contains('revealed')) el.classList.add('revealed');
      } else {
        el.classList.remove('revealed');
      }
    });
    if (!paused) {
      requestAnimationFrame(tick);
    }
  };

  function pauseAnimation() {
    paused = true;
    pauseAnimationTime = (performance.now() - startTime - resumeAnimationTime) % totalAnimationTime;
  }

  function resumeAnimation() {
    paused = false;
    // Adjust resumeTime so animation continues smoothly
    resumeAnimationTime = performance.now() - startTime - pauseAnimationTime;
    requestAnimationFrame(tick);
  }

  // Manage focusability of elements on the back face so hidden content is not tabbable
  function setBackFaceFocusable(card, enable) {
    const back = card.querySelector('.product-card__face--back');
    if (!back) return;

    back.setAttribute('aria-hidden', enable ? 'false' : 'true');

    // Using inert ensures the entire subtree is removed from the tab order and is non-interactive
    back.inert = !enable;
  }

  // Unflip all other cards to ensure only one is flipped at a time
  function unflipAllExcept(currentCard, allCards) {
    allCards.forEach((c) => {
      if (c === currentCard) return;
      if (c.getAttribute('data-flipped') === 'true') {
        c.setAttribute('data-flipped', 'false');
        c.setAttribute('aria-expanded', 'false');
        setBackFaceFocusable(c, false);
      }
    });
  }

  // Toggle card flipped state and update focusability
  const toggleCard = (card, allCards) => {
    const isFlipped = card.getAttribute('data-flipped') === 'true';
    const nextState = isFlipped ? 'false' : 'true';

    // If we're about to flip this card open, close all others first
    if (nextState === 'true') {
      unflipAllExcept(card, allCards);
    }

    card.setAttribute('data-flipped', nextState);
    card.setAttribute('aria-expanded', nextState);
    setBackFaceFocusable(card, nextState === 'true');
  };

  // Initialize product cards: set initial back-face focus state and event handlers
  productCards.forEach((card) => {
    const initiallyFlipped = card.getAttribute('data-flipped') === 'true';
    setBackFaceFocusable(card, initiallyFlipped);

    card.addEventListener('click', (event) => {
      const target = event.target;
      // If click is on an interactive element within the back face CTA area, ignore toggling
      if (target.closest('.product-card__back-cta')) return;
      toggleCard(card, productCards);
    });

    card.addEventListener('keydown', (event) => {
      const target = event.target;
      const isInteractiveElement = target.closest('.product-card__back-cta');
      if (event.key === 'Enter' || event.key === ' ') {
        if (isInteractiveElement) return;
        event.preventDefault();
        toggleCard(card, productCards);
      }
    });
  });

  function isIOS() {
    const ua = navigator.userAgent || '';
    const platform = navigator.platform || '';
    const isIOSDevice = [
      'iPad Simulator',
      'iPhone Simulator',
      'iPod Simulator',
      'iPad',
      'iPhone',
      'iPod'
    ].includes(platform) || /iPad|iPhone|iPod/.test(ua);
    const isIPadOS = platform === 'MacIntel' && navigator.maxTouchPoints > 1;
    if (isIOSDevice || isIPadOS) return true;

    const isMac = /Mac/.test(platform);
    if (!isMac) return false;

    const isSafari = /Safari/.test(ua) && !/Chrome|CriOS|Edg|OPR|Firefox|FxiOS/.test(ua);
    return isSafari;
  }

  if (isIOS() && ball) {
    ball.style.opacity = 0;
  } else {
    ball.style.opacity = 1;
  }

  const videoObserver = new IntersectionObserver(
    ([entry], obs) => {
      if (!entry?.isIntersecting) return;

      const section = entry.target;
      const video = section.querySelector('video.background-video');
      if (!video) return;

      video.querySelectorAll('source').forEach(srcEl => {
        if (srcEl.dataset.src && !srcEl.getAttribute('src')) {
          srcEl.src = srcEl.dataset.src;
        }
      });

      video.load();

      const tryPlay = () => video.play().catch(() => {});

      if (video.readyState >= 2) {
        tryPlay();
      } else {
        video.addEventListener('canplay', tryPlay, { once: true });
      }

      obs.unobserve(section);
    },
    { root: null, rootMargin: '300px 0px', threshold: 0.01 }
  );
  const videoSection = document.querySelector('.video-banner-section.home-page-section');
  if (videoSection) videoObserver.observe(videoSection);

  const slidesPauseBtn = document.getElementById('slide-pause-btn');
  const sliderTrack = document.querySelector('.slider-track');
        
  slidesPauseBtn.addEventListener("click", ()=> {
    sliderTrack.classList.toggle("pause");
    toggleAnimationBtn(sliderTrack.classList.contains("pause"), slidesPauseBtn);
  })

  function toggleAnimationBtn(isPaused, btn) {
    const pauseIcon = btn.querySelector(`.aniamtion-control-btn .paused`);
    const playIcon = btn.querySelector(`.aniamtion-control-btn .play`);
    const hoverText = btn.querySelector('.aniamtion-hover-text');
    if (isPaused) {
      pauseIcon.classList.add("hide");
      playIcon.classList.remove("hide");
      hoverText.textContent = "Play";
    } else {
      pauseIcon.classList.remove("hide");
      playIcon.classList.add("hide");
      hoverText.textContent = "Pause";
    }
  }

  const elearningPauseBtn = document.getElementById('elearning-pause-btn');
  const rollingBall = document.getElementById('rolling-ball');
  const animatedContentDescription = document.querySelector('.elearning-content-animation-section__description.animated');
  const contentDescription = document.querySelector('.elearning-content-animation-section__description.non-animated');
  let isPaused = false;

  elearningPauseBtn.addEventListener("click", ()=> {
    if (!isPaused) {
      rollingBall.classList.add("is-paused");
      pauseTyping();
      toggleAnimationBtn(isPaused, elearningPauseBtn);
      animatedContentDescription.classList.add('sr-only');
      contentDescription.classList.remove('sr-only');
    } else {
      rollingBall.classList.remove("is-paused");
      resumeTyping();
      toggleAnimationBtn(isPaused, elearningPauseBtn);
      animatedContentDescription.classList.remove('sr-only');
      contentDescription.classList.add('sr-only');
    }
  })

  const videoPauseBtn = document.getElementById('video-pause-btn');
  const backgroundVideo = document.querySelector('.background-video');
  let isVideoPause = false;
  
  videoPauseBtn.addEventListener("click", ()=> {
    if (backgroundVideo.paused) {
      backgroundVideo.play();
      toggleAnimationBtn(backgroundVideo.paused, videoPauseBtn);
    } else {
      backgroundVideo.pause();
      toggleAnimationBtn(backgroundVideo.paused, videoPauseBtn);
    }
  })

  const mobileViewMarkers = document.querySelectorAll(".camera-viewport .overlay .marker");
  const heroPauseBtn = document.getElementById('hero-pause-btn');
  const container = document.querySelector('.gradients-container');
  const childrenArray = Array.from(container.children);

  heroPauseBtn.addEventListener("click", ()=> {
    if (!isHeroPaused) {
        if(window.innerWidth > 768) {
          pauseAnimation();
          childrenArray.forEach(child => {
            child.classList.add("is-paused");
          })
        }
        isHeroPaused = true;
        toggleAnimationBtn(isHeroPaused, heroPauseBtn);
        mobileViewMarkers.forEach(child => {
          child.classList.add("pause")
        })
      } else {
        if(window.innerWidth > 768) {
          resumeAnimation();
          childrenArray.forEach(child => {
            child.classList.remove("is-paused");
          })
        }
        isHeroPaused = false;
        toggleAnimationBtn(isHeroPaused, heroPauseBtn);
        mobileViewMarkers.forEach(child => {
          child.classList.remove("pause")
        })
      }
  })

  function syncHeroAnimationState() {
    if (isHeroPaused) {
      pauseAnimation();
      childrenArray.forEach(child => {
        child.classList.add("is-paused");
      })
    } else {
      resumeAnimation();
      childrenArray.forEach(child => {
        child.classList.remove("is-paused");
      })
    }
  }
};


if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initHomePage);
} else {
  initHomePage();
}

