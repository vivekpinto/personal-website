let siteKey;
let globalResolve;
let newPromise = new Promise ((resolve) => {
    globalResolve = resolve;
})
function initializeSiteKey(key) {
    siteKey = key;
    globalResolve();
}

function loadRecaptcha(siteKey) {
  return new Promise((resolve) => {
    const script = document.createElement("script");
 
    script.src = `https://www.google.com/recaptcha/api.js?render=${siteKey}`;
    script.defer = true;
 
    script.onload = () => resolve();
 
    document.head.appendChild(script);
  });
}
 
async function init() {
  await loadRecaptcha(siteKey);
}

newPromise.then(()=>{
    init();
})

function waitForRecaptcha() {
  return new Promise((resolve) => {
    if (window.grecaptcha && window.grecaptcha.execute) {
      resolve();
      return;
    }
 
    const interval = setInterval(() => {
      if (window.grecaptcha && window.grecaptcha.execute) {
        clearInterval(interval);
        resolve();
      }
    }, 100);
  });
}

window.sendDisable = () => {
    const recaptchaError = document.getElementById("recaptcha-error");
    if (!recaptchaError) return;
    recaptchaError.style.display = "block";
};

window.sendEnable = () => {
    const recaptchaError = document.getElementById("recaptcha-error");
    if (!recaptchaError) return;
    recaptchaError.style.display = "none";
};

function setAriaLiveText() {
    const liveTextContainer = document.getElementById(`contact-us-live-text`);
    if(!liveTextContainer) return;
    liveTextContainer.textContent = "";
    const titleText = document.querySelector('.success-message-wrapper__title').getAttribute('data-text');
    const messageText = document.querySelector('.success-message-wrapper__description').getAttribute('data-text');
    const successText = `${titleText} ${messageText}`;
    setTimeout(() => {
    liveTextContainer.textContent = successText;
    }, 100);
}

document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("[data-js='contact-form']");
    const status = document.querySelector("[data-js='status']");
    const successMessage = document.getElementById("success-message-section-dialog");
    const demoMessage = document.getElementById("demo-contact-hero-dialog");
    const dialogPopup = document.getElementById("successDialog");
    const backdrop = document.getElementById("successContactBackdrop");

    const fields = [
        document.getElementById("contact-name"),
        document.getElementById("contact-email"),
        document.getElementById("contact-message")
    ];

    let formIsValid = false;

    // Validate on blur
    fields.forEach(field => {
        field.addEventListener("blur", () => {
            validateField(field);
            updateFormValidity();
        });
    });

    function validateField(field) {

        const emailRegex = /^[^\s@]+@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
        let isValid = true;

        if (!field.value.trim()) {
            isValid = false;
        }

        // Special case for email format
        if (field.type === "email" && field.value.trim()) {
            if (!emailRegex.test(field.value.trim())) {
            isValid = false;
            }
        }

        if (!isValid) {
            showError(field);
        } else {
            hideError(field);
        }

        return isValid;
    }


    function showError(field) {
        field.setAttribute("aria-invalid", "true");
        field.classList.add("error");
    }


    function hideError(field) {
        field.setAttribute("aria-invalid", "false");
        field.classList.remove("error");
    }

    function updateFormValidity() {
        formIsValid = fields.every(field => {
            if (!field.value.trim()) return false;
            if (field.type === "email" && !field.validity.valid) return false;
            return true;
        });
    }

    function getFocusableElements(container) {
      return container.querySelectorAll(
        'button[id="success-ok-btn"]'
      );
    }

    function trapFocus(dialog) {
      const focusableElements = getFocusableElements(dialog);
      if (!focusableElements.length) return;

      const first = focusableElements[0];
      const last = focusableElements[focusableElements.length - 1];

      dialog.addEventListener('keydown', function (e) {
        if (e.key !== 'Tab') return;

        if (e.shiftKey) {
          if (document.activeElement === first) {
            e.preventDefault();
            last.focus();
          }
        } else {
          if (document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      });

      first.focus();
    }

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const recaptchaError = document.getElementById("recaptcha-error");
        if (!recaptchaError) return;

        if (!formIsValid) {
            let firstInvalidField = null;

            for (const field of fields) {
                const isValid = validateField(field);
                if (!isValid && !firstInvalidField) {
                    firstInvalidField = field; 
                }
            }
            if (firstInvalidField) {
                firstInvalidField.focus();
            }
            return;
        }
        await waitForRecaptcha();

        grecaptcha.ready(function () {
            grecaptcha
                .execute(siteKey, {
                    action: "submit",
                })
                .then((token) => {
                    if (token === "") {
                        recaptchaError.style.display = "block";
                        recaptchaError.textContent =
                            "Please complete this verification.";
                        setTimeout(() => {
                            recaptchaError.setAttribute("role", "alert");
                            recaptchaError.setAttribute("aria-atomic", "true");
                        }, 1000);
                        return;
                    }
                    status.style.display = "block";
                    status.textContent = "Sending...";
                    const payload = Object.fromEntries(new FormData(form).entries());

                    const headers = {
                        "Content-Type": "application/json",
                        "X-grecaptcha-token": token,
                    };

                    fetch("/api/contact-us", {
                        method: "POST",
                        headers,
                        body: JSON.stringify(payload),
                    })
                    .then((res) => {
                        return res.json();
                    })
                    .then((data) => {
                        if (data.success) {
                            status.textContent = "Thanks! Your message has been sent.";
                            if (successMessage && demoMessage) {
                                successMessage.classList.add('is-visible');
                                demoMessage.classList.add('is-hide');
                            }
                            if(backdrop && dialogPopup) {
                                window.scrollTo(0, 0);
                                backdrop.classList.add('is-visible');
                                dialogPopup.classList.add('is-visible');
                                document.body.classList.add('overflow-hidden');
                               trapFocus(dialogPopup);
                            }
                            form.reset();
                            setAriaLiveText();
                        } else {
                            status.textContent = "Error sending form.";
                        }
                    })
                    .catch((err) => {
                        status.textContent = "Error sending form.";
                    });
                })
                .catch((err) => {
                    recaptchaError.style.display = "block";
                    recaptchaError.textContent =
                        "reCAPTCHA verification failed. Please try again.";
                });
        });
    });
});