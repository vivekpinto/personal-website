const SALT = "zeus";

const encodeBase64Email = (email) => {
  try {
    return btoa(`${SALT}${email}${SALT}`);
  } catch (error) {
    return "";
  }
};

const decodeBase64Email = (encodedEmail) => {
  try {
    const decoded = atob(encodedEmail);
    if (!decoded.startsWith(SALT) || !decoded.endsWith(SALT)) {
      return "";
    }
    return decoded.slice(SALT.length, decoded.length - SALT.length);
  } catch (error) {
    return "";
  }
};

// Swap base64 placeholders with real mailto links once the DOM is ready.
const updateFooterEmails = () => {
  const emailElements = document.querySelectorAll("[data-email]");

  emailElements.forEach((element) => {
    let encodedEmail = element.getAttribute("data-email");
    let locationData = element.getAttribute("data-location");
    if (!encodedEmail) {
      const fallbackEmail = element.textContent?.trim() ?? "";
      encodedEmail = fallbackEmail ? encodeBase64Email(fallbackEmail) : "";
      if (encodedEmail) {
        element.setAttribute("data-email", encodedEmail);
      }
    }

    const decodedEmail = decodeBase64Email(encodedEmail);
    if (!decodedEmail) {
      return;
    }

    element.textContent = decodedEmail;
    if (element instanceof HTMLAnchorElement) {
      element.setAttribute("href", `mailto:${decodedEmail}`);
      element.setAttribute("aria-label", `Send Email to ${decodedEmail}, ${locationData}`);
    }
  });
};

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", updateFooterEmails, {
    once: true,
  });
} else {
  updateFooterEmails();
}
