  document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("demo-contactForm");
    const status = document.getElementById("demo-status");
    const successMessage = document.getElementById("success-message-section-dialog");
    const demoMessage = document.getElementById("demo-contact-hero-dialog");
    const successMessageOk = document.querySelector('.success-message-wrapper__submit');
    const closeBtn = document.getElementById("close-button");
    let lastFocusedElement = null;
    let captchaId = null;

    window.sendDisable = () => {
      const recaptchaError = document.getElementById("recaptcha-error");
      if (!recaptchaError) return;
      recaptchaError.style.display = "block";
    };

    window.sendEnable = () => {
      const recaptchaError = document.getElementById("recaptcha-error");
      if (!recaptchaError) return;
      recaptchaError.style.display = "none";
    };

    cleanUp();
    initDialog();

    function initDialog() {
      const dialog = document.getElementById("myFormDemoDialog");
      const backdrop = document.getElementById("demoContactBackdrop");
      dialog.classList.add('display-none')
      if (!dialog) return;
      if(!successMessageOk) {
        console.warn("not found ok button");
        return;
      }

      document.addEventListener("click", (e) => {
        const openTrigger = e.target.closest("[data-open-demo-dialog]");
        if (openTrigger) {
          e.preventDefault();
          e.stopImmediatePropagation();
          e.stopPropagation();
          lastFocusedElement = openTrigger;
          // Use non-modal dialog so the reCAPTCHA challenge can appear above it.
          dialog.show();
          inertAllSection(true);
          if (backdrop) {
            backdrop.classList.add("is-visible");
            backdrop.setAttribute("aria-hidden", "false");
          }
          
          dialog.classList.remove('display-none')
          trapFocus(dialog);
          return; 
        }

        dialog.addEventListener("click", (event) => {
          if (event.target === dialog) {
            dialog.close();
            inertAllSection(false);
            resetError();
            dialog.classList.add('display-none')
            cleanUp();
            if (backdrop) {
              backdrop.classList.remove("is-visible");
              backdrop.setAttribute("aria-hidden", "true");
            }
          }
        });
      });

      document.addEventListener('keydown', (event) => {
          if (event.key === 'Escape') {
            if(dialog && dialog.open) {
              dialog.close();
              inertAllSection(false);
              dialog.classList.add('display-none')
              resetError();
              cleanUp();
              if (backdrop) {
                backdrop.classList.remove("is-visible");
                backdrop.setAttribute("aria-hidden", "true");
              }
            }
          }
      });

      closeBtn.addEventListener("click", () => {
        if(dialog.open) {
          dialog.close();
          inertAllSection(false);
          dialog.classList.add('display-none')
          resetError();
          cleanUp();
          if (backdrop) {
            backdrop.classList.remove("is-visible");
            backdrop.setAttribute("aria-hidden", "true");
          }
        }
      });

      if (backdrop) {
        backdrop.addEventListener("click", () => {
          if (dialog && dialog.open) {
            dialog.close();
            inertAllSection(false);
            dialog.classList.add('display-none')
            resetError();
            cleanUp();
            backdrop.classList.remove("is-visible");
            backdrop.setAttribute("aria-hidden", "true");
          }
        });
      }

      successMessageOk.addEventListener('click', (event)=>{
        dialog.close();
        inertAllSection(false);
        dialog.classList.add('display-none');
        resetError();
        cleanUp();
        if (backdrop) {
          backdrop.classList.remove("is-visible");
          backdrop.setAttribute("aria-hidden", "true");
        }
      })
    }

    function hideError(field) {
        field.setAttribute("aria-invalid", "false");
        field.classList.remove("error");
    }
    
    function resetError() {
      const fields = [
        document.getElementById("contact-name"),
        document.getElementById("contact-email"),
        document.getElementById("contact-message")
      ];
      fields.forEach(field => {
          hideError(field);
      })
    }

    function getFocusableElements(container) {
      return container.querySelectorAll(
        'input, button[type="submit"], textarea, button[id="close-button"]'
      );
    }

    function trapFocus(dialog) {
      const focusableElements = getFocusableElements(dialog);
      if (!focusableElements.length) return;

      const first = focusableElements[0];
      const last = focusableElements[focusableElements.length - 1];

      dialog.addEventListener('keydown', function (e) {
        if (e.key !== 'Tab') return;

        if (e.shiftKey) {
          if (document.activeElement === first) {
            e.preventDefault();
            last.focus();
          }
        } else {
          if (document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      });

      first.focus();
    }

    function cleanUp() {
      if(!successMessage || !demoMessage || !status) {
        return;
      }
      if (lastFocusedElement) {
        lastFocusedElement.focus();
        lastFocusedElement = null;
      }
      successMessage.classList.remove('is-visible');
      demoMessage.classList.remove('is-hide');
      status.textContent = "";
    }

    function inertAllSection(isInert) {
      const sections = document.getElementsByClassName("home-page-section");
      if(isInert) {
        [...sections].forEach(section => {
          section.setAttribute("inert", "");
          section.setAttribute("aria-hidden", "true");
        });
      } else {
        [...sections].forEach(section => {
          section.removeAttribute("inert");
          section.removeAttribute("aria-hidden");
        });
      }
    }
  });