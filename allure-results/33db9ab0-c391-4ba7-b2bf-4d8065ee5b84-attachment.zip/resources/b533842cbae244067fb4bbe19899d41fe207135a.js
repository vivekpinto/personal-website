document.querySelector('.skip-link').addEventListener('keydown' , (e) => {
    if (e.key == ' ') {
        e.target.click();
        e.preventDefault();
    }
})